
function main(){
	let num1 = document.querySelector("#number1").value;
	let num2 = document.querySelector("#number2").value;
	let operation = document.querySelector("#operations").value;
	let num3 = ""
	
	function addition(){
		if(operation == "+"){
		num3 = parseFloat(num1) + parseFloat(num2);
		}
	};
	
	function subtraction(){
		if(operation == "-"){
		num3 = parseFloat(num1) - parseFloat(num2);
		}
	};
	
	function multiplication(){
		if(operation == "x"){
		num3 = parseFloat(num1) * parseFloat(num2);  
		}
	};
	
	function division(){
		if(operation == "/"){
		num3 = parseFloat(num1) / parseFloat(num2);
		}
	};
	
	
	
	
	addition();
	subtraction();
	multiplication();
	division();
	document.querySelector("#answer").textContent = num3;
  };





	  



