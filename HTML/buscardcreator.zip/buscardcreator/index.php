
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Business Card Builder</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="style.css">
	</head>
	<body>
		<h1>Welcome to the Business Card Builder</h1>
			<hr>
			<p>Here you can build your own business card</p>
		
		<h4>Down Below Please fill out the form:</h4>
		<div class="card">
			<form action="form.php" method="POST"> 
				<label>First Name:</label>
				<input type="text" id="firstname" placeholder="Enter your first name here!" name="firstname"><br>
				
				<label>Last Name:</label>
				<input type="text" id="lastname" placeholder="Enter your last name here!" name="lastname"><br>
				
				<label>Email:</label>
				<input type="text" id="email" placeholder="Enter your Email address here!" name="email"><br>
				
				<label>organization:</label>
				<input type="text" id="organization" placeholder="Enter your organization here" name="organization"><br>
				
				<label>Title:</label>
				<input type="text" id="title" placeholder="Enter your title here" name="title"><br>
				
				<label>Phone Number:</label>
				<input type="text" id="phone" placeholder="Enter your phone number here" name="phone"><br>
				
				<label>Address:</label>
				<input type="text" id="address" placeholder="Enter your address here" name="address"><br>
				
				<label>City:</label>
				<input type="text" id="city" placeholder="Enter your city here" name="city"><br>
				
				<label>State:</label>
				<input type="text" id="state" placeholder="Enter your state here" name="state"><br>
				
				<label>Zip Code:</label>
				<input type="text" id="zip" placeholder="Enter your zip here" name="zip"><br>
				
				<input type="submit" value="Generate Business Card">
				</form>	
		</div>
	
	</body>
</html>