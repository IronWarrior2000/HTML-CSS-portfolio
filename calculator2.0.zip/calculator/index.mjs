
import {calculator} from "./calculator.mjs");

function main(){
	document.addEventListener("DOMContentLoaded",function(){
	equal = document.querySelector("#equal");
	equal.addEventListener("click",calculator);
})};



main();


	  



