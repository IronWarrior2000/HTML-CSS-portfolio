<?php
	
	$firstname = $_POST['firstname'];
	$lastname = $_POST["lastname"];
	$email = $_POST["email"];
	$organization = $_POST["organization"];
	$title = $_POST["title"];
	$phone = $_POST["phone"];
	$address = $_POST["address"];
	$city = $_POST["city"];
	$state = $_POST["state"];
	$zip = $_POST["zip"];
	?>
	
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Business Card</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="style.css">
	</head>
	<body>
		<h1> <?php echo $firstname. " ". $lastname ?></h1>
		<p> <?php echo "Reach me at ". $email. " or ". $phone ?></p>
		<h4> <?php echo $organization. " | ". $title ?></h4>
		<p> <?php echo $city ." ". $state ." " . $zip ?></p>
	</body>
</html>