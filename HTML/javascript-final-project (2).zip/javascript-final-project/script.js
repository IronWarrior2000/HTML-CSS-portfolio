function ratingslider(value) {
document.getElementById("ratingslider").innerHTML = value;
}

$(function displayname() {
  $('#form').on('submit', function(evnt) {
    evnt.preventDefault();
      let yourname = document.querySelector('#name').value;
      document.querySelector('#your_name').innerHTML = yourname;
  });
});

$(function displayelements() {
  $('#form').on('submit', function(evnt) {
    evnt.preventDefault();
      let elemental = document.querySelector('#elemental').value;
      document.querySelector('#elements').textContent = elemental;
	  
	  
	  let elelist = ["fire","water","nature","earth","wind","Electric/Lightning", "Light", "Gravity", "Time", "Summoning", "Ice", "Poison", "Metal", "Space", "Psychics", "Dark"];
	  elelist.push(elemental);
	  let elelistprint = elelist.length;
	 document.querySelector("#elists").textContent = elelistprint;
	 
  });
});

let title = document.querySelector("#formtitle").style.color = "navy";

$(function thankyou(){
	$("#form").on("submit",function(evnt){
		evnt.preventDefault();
		let thanksyou = document.querySelector("#thanksyou");
		let thankyou = document.createElement("p");
		let thankyoutext = document.createTextNode("Thank you");
		thanksyou.appendChild(thankyoutext);
		thanksyou.appendChild(thankyou);
  });
});

$(function feedimage(){
	$("#form").on("submit",function(evnt){
		evnt.preventDefault();
	let feedtothank = document.querySelectorAll("img")[16];
	feedtothank.src = "images/element/thankyou.jpg"
  });
});

$(function() {
  $('#form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#one').checked){
	  document.querySelector('#support').textContent = "for the support, we sorry for the inconvience, the feedback is heard and will be fix in the near future.";
	  }});
});

$(function() {
  $('#form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#two').checked){
	  document.querySelector('#support').textContent = "for the support, we sorry for the inconvience, the feedback is heard and will be fix in the near future.";
	  }});
});

$(function() {
  $('#form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#three').checked){
	  document.querySelector('#support').textContent = "for the support, we sorry for the inconvience, the feedback is heard and will be fix in the near future.";
	  }});
});

$(function() {
  $('#form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#four').checked){
	  document.querySelector('#support').textContent = "for the support, we sorry for the inconvience, the feedback is heard and will be fix in the near future.";
	  }});
});

$(function() {
  $('#form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#five').checked){
	  document.querySelector('#support').textContent = "for the support, we sorry for the inconvience, the feedback is heard and will be fix in the near future.";
	  }});
});

$(function() {
  $('#form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#six').checked){
	  document.querySelector('#support').textContent = "for the support, please look forward to further changes and element addons.";
	  }});
});

$(function() {
  $('#form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#seven').checked){
	  document.querySelector('#support').textContent = "for the support, please look forward to further changes and element addons.";
	  }});
});

$(function() {
  $('#form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#eight').checked){
	  document.querySelector('#support').textContent = "for the support, please look forward to further changes and element addons.";
	  }});
});

$(function() {
  $('#form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#nine').checked){
	  document.querySelector('#support').textContent = "for the support, please look forward to further changes and element addons.";
	  }});
});

$(function() {
  $('#form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#ten').checked){
	  document.querySelector('#support').textContent = "for the support, please look forward to further changes and element addons.";
	  }});
});


let feform = document.querySelector("#feedback")
feform.style.width = "200px";
feform.style.height = "150px";

let favor1 = document.querySelector("favor");

let elelist = ["fire","water","nature","earth","wind","Electric/Lightning", "Light", "Gravity", "Time", "Summoning", "Ice", "Poison", "Metal", "Space", "Psychics", "Dark"];

function startbutton(){
	let rannum= Math.ceil(Math.random() * 100);
	let count = 0;
	
	let gnum=Number(prompt("Enter in your guess for a number between 1-100"));
	
	while(gnum !== rannum){count++;	
	if(gnum < rannum){
		alert ("Your number " +gnum+" is too low");
	}
	else{
		alert("Your number " +gnum+" is too high");
	}
gnum=Number(prompt("Enter in your guess for a number between 1-100"));
	};	
document.getElementById("#gamefinder").innerHTML = "CONGRATS!!! YOU FOUND THE MYSTERIOUS GUESSING MINI-GAME";

};

