function calculatingpay(){
	let hours; 	
	let payrate;
	let keepgoing=prompt("Do you want to continue?");
while(keepgoing === "yes"){
	hours = Number(prompt("How many hours did you work in total?")); 
	payrate = Number(prompt("What is your payrate?"));
	if(hours <= 40)
		alert("This pay is" +(payrate*hours));
	else
		alert("This pay is" +(40*payrate)+(hours-40)*1.5*payrate);
	keepgoing=prompt("Do you want to continue?");
}
}




