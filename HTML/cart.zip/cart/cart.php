<?php


//Cart.php


require_once('index.php');



//New Cart Class
class ShoppingCart {
    private $storeditems = [];
	
	//Adding Items
    public function addItem($item) {
    array_push($this->storeditems, $item);
  }
  
	//Removing Items
    public function removeItem($productId) {
        if (isset($this->storeditems[$productId])) {
            unset($this->storeditems[$productId]);
        }
    }
	
	//Get number of Items (physically)
    public function getNumItems() {
    return count($this->storeditems);
  }
	
	//Get items individually (backend)
    public function getItems() {
        return $this->storeditems;
    }

//Totals price of all items
    public function getTotalPrice() {
    $total = 0;
    foreach ($this->storeditems as $item) {
      $total += $item->getPrice();
    }
    return $total;
  }

//Empty Cart
    public function emptyCart() {
        $this->storeditems = array();
    }
}


	
	
	
	
	
	
	





?>