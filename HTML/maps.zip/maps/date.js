//Created the main function to operate all of the traffic back to here
function main(){
	document.addEventListener("DOMContentLoaded",function(){
		let submitB = document.querySelector("#submit");
		//Once the user click the submit button, it will trigger the getDates functions
		submitB.addEventListener("click",getDates);
	});
};

//getDates is for fetching the dates from the JSON file and bring it back into the function to reorganize it into the date method
function getDates(ff){
	ff.preventDefault();
	fetch("dates.json")
			.then(function (response){
				return response.json()
			})
			.then(function (data){
				let upDates = data.map(value => {					
						const year = value.slice(4);
						const day = value.slice(0, 2) - 1;
						const month = value.slice(0, 2) - 1;
						
						//Processing the Date as ISO so it can be easily be read by sort
						let latest = new Date(year, month, day).toISOString("en-us", { year:"numeric", month:"2-digit", day:"2-digit"});
						return latest;
					});
				//Calling the filtering Dates so that the promise can quickly go to the function and preform the filteration and reducing the amount in the array.
				filteringDates(upDates);	
			})
			.catch(function (error){
				console.log("ERROR");
			});
		
		}

//Created filteringDates to filter out the dates down to what the user would want
//This would be the earliest date possible
function filteringDates(upDates){
	let userYear = document.querySelector("#userYear").value;
	let yearSort = upDates.sort();

	let filterRecords = yearSort.filter(value => {
		return value >= userYear;
	});	
	let earliestDate = filterRecords.reduce(value => {
		return filterRecords[0];
	});
//Also added a way to put it into the document itself in order for the user to see the date.
	contentArea = document.querySelector("#date").textContent = earliestDate;
}

main();

//	FOR SERVER TESTING PURPOSE (DO NOT TOUCH!!! Thank you!)			
//			py -m http.server --bind 127.0.0.1
