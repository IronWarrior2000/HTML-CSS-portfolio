class Items{
    constructor(itemNum, name, mealType, price, spicy, vegan){
        this.name = name;
        this.price = price;
        this.itemNum = itemNum;
        this.mealType = mealType;
        this.spicy = spicy;
        this.vegan = vegan;

    }

    getName() {
        return this.name;
    };

    getPrice() {
        return this.price;
    };

    getItemNum() {
        return this.itemNum;
    };

    getMealType() {        
        return this.mealType;
    };

    isVegan(ele) {
        const itemElement = document.createElement('div');
        const vegElement = document.createElement('p');
        if(this.vegan == true){
            let veganText = "Vegan!";
            vegElement.textContent = veganText;
            ele = itemElement.appendChild(vegElement);
            return ele; 
        } 
        else{
            let veganText = '';
            vegElement.textContent = veganText;
            ele = itemElement.appendChild(vegElement);
            return ele; 
        }
    };

    isSpicy(spi) {
        const itemElement = document.createElement('div');
        const spicyElement = document.createElement('p');
        if(this.spicy == true){
            let spicetext = "Spicy!";
            spicyElement.textContent = spicetext;
            spi = itemElement.appendChild(spicyElement);
            return spi;
        } 
        else{
            let spicetext = '';
            spicyElement.textContent = spicetext;
            spi = itemElement.appendChild(spicyElement);
            return spi;
        }
        
        
    };

}

export default Items;