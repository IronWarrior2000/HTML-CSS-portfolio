<?php
	require_once("Cart.php");
	require_once("Items.php");
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Shopping Cart</title>
		<link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
	</head>
	
	<body>
		<h1>Welcome to the Forge</h1>
		<?php 
	//Creating New Items
			$item1 = new Item("Sword", 49.99);
			$item2 = new Item("Helmet", 99.99);
			$item3 = new Item("Bow", 69.99);
			$item4 = new Item("Chestplate", 199.99);

	// Create cart and add items
		$cart = new ShoppingCart();
		$cart->addItem($item1);
		$cart->addItem($item2);
		$cart->addItem($item3);
		$cart->addItem($item4);
		echo "<h2>Shopping Cart</h2>";
		echo "<p>Number of items: " . $cart->getNumItems() . "</p>";
		echo "<ul>";
		foreach ($cart->getItems() as $item) {
		echo "<li>" . $item->getName() . " - $" . $item->getPrice() . "</li>";
		}
		echo "</ul>";
		echo "<p>Total price: $" . $cart->getTotalPrice() . "</p>";
		?>
	</body>




</html>