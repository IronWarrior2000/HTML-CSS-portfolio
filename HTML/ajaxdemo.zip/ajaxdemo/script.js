function getHello(){
		$("#welcome").load("hello.txt")

};