<?php
	//Departments Database Extraction
	$departments = new PDO('sqlite:data.db');
	
	//Departments GET and Security
	$departmentsLimits = $_GET['name'] ?? '';
	$departmentsNameParam = addcslashes($departmentsLimits, '_%'). '%';
	
	$departmentsIdLimits = $_GET['department_id'] ?? '';
	$departmentsIdParam = addcslashes($departmentsIdLimits, '_%'). '%';

	//Departments Query
	$queryDepartments = $departments->prepare(
		'SELECT department_id, name
		 FROM departments
		 WHERE department_id LIKE :department_id AND name LIKE :name'
		);
	$queryDepartments->execute([
		':department_id' => $departmentsIdParam,
		':name' => $departmentsNameParam
	]);
	$trueDepartments = $queryDepartments->fetchAll(PDO::FETCH_ASSOC);
	
	//Departments Content Type and Print in JSON data.
	header('Content-Type: application/json');
	print json_encode($trueDepartments);
	
?>