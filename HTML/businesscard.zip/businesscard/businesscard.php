<!--Created by Bill Nguyen | 1/21/23 | CIS 244 | Liss Lawrence | Making a Business Card-->

<?php
define("Address", "1700 Spring Garden St.");
$name = "Bill Nguyen";
$role = "Student";
$class = "CIS-244";
$school = "Community College of Philadelphia";
$city = "Philadelphia PA 19130";
$email = "bnguye46@student.ccp.edu"; 

?>

<html>
	<head>
		<title>Digital Business Card</title>
		<meta charset="utf-8">
	</head>
	<body>

		<h1><?php
		print $name;
		?></h1>
		
		<h2><?php print $role;
		?></h2>
		
		<h3><?php print $class;?></h3>
		<h4><?php print $school;?></h4>
		<h5><?php print Address?></h5>
		<h5><?php print $city; ?></h5>
		<p><a href="mailto:"><?php 
		
		print $email
		
		
		
		?></a></p>
	
	</body>

</html>