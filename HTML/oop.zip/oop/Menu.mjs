class Menu{
    constructor(item){
        this.item = [];
        
    }

    addItem(item) {
        this.item.push(item);

    }
          
    getItems() {
        return this.items;
    }

    filterByType(type) {
        return this.item.filter((item) => item.getMealType() === type);
        
      }
    
    filterByPrice(price) {
        return this.item.filter((item) => item.getPrice() <= price);
      }
    
    filterByVegan(isVegan) {
        return this.item.filter((item) => item.isVegan() === isVegan);
      }
    
    filterBySpice(isSpicy) {
        return this.item.filter((item) => item.isSpicy() === isSpicy);
      }
    


    





}

export default Menu;



//