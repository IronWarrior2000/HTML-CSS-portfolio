<?php
	//Credits Database Extraction
	$credits = new PDO('sqlite:data.db');
	
	//Credits Security
	$creditsLimits = $_GET['credits'] ?? '';
	$creditsParam = addcslashes($creditsLimits, '_%'). '%';

	//Credits Query
	$queryCredits = $credits->prepare(
		'SELECT DISTINCT credits
		 FROM class
		 WHERE credits LIKE :credits
		 ORDER BY credits ASC'
		);
	$queryCredits->execute([
		':credits' => $creditsParam
	]);
	$trueCredits = $queryCredits->fetchAll(PDO::FETCH_COLUMN);
	
	//Credits Content Typing and Print in JSON Data
	header('Content-Type: application/json');
	print json_encode($trueCredits);
	 
?>