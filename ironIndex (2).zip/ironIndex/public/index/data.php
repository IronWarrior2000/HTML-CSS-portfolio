<?php
    require_once('collector.php');

    print json_encode($monsters);
?>
