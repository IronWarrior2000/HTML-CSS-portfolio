import Menu from './Menu.mjs';
import Items from './Items.mjs';







function main(){
    const menu = new Menu();
    menuList(menu);
    filteringData(menu);

   

}


function menuList(menu){
    let item = [];

    menu.addItem(new Items("1","Cheeseburger", "Lunch", 5.99, false, false));
    menu.addItem(new Items("2","Chicken Sandwich", "Lunch", 5.99, false, false));
    menu.addItem(new Items("3","Fries", "Lunch", 3.99, false, false));
    menu.addItem(new Items("4","Caesar Salad", "Lunch", 7.99, false, true));
    menu.addItem(new Items("5","Spaghetti and Spicy MeatBall", "Dinner", 12.99, true, false));
    menu.addItem(new Items("6","Rice with Fish", "Dinner", 12.99, false, false));
    menu.addItem(new Items("7","Ribeye Steak", "Dinner", 12.99, false, false));
    menu.addItem(new Items("8"," Miso Tofu Wrap", "Dinner", 12.99, false, true));
    menu.addItem(new Items("9","Oatmeal", "Breakfest", 4.99, false, true));
    menu.addItem(new Items("10","French-Toast", "Breakfest", 9.99, false, true));
    menu.addItem(new Items("11","Pancake with Bacon and Egg", "Breakfest", 12.99, false, false));
    menu.addItem(new Items("12","Spicy Black Beans Burrito", "Breakfest", 9.99, true, false));
    menu.addItem(new Items("13","Spicy Popcorn Chicken", "Appetizer", 4.99, true, false));
    menu.addItem(new Items("14","Bread Sticks", "Appetizer", 4.99, false, true));
    menu.addItem(new Items("15","Apple Slices", "Appetizer", 2.99, false, true));
    menu.addItem(new Items("16","Pretzel Bites", "Appetizer", 3.99, false, true));
    menu.addItem(new Items("17","Cheesecake", "Desserts", 7.99, false, false));
    menu.addItem(new Items("18","Chocolate Cake", "Desserts", 12.99, false, false));
    menu.addItem(new Items("19","Ice Cream Sundae", "Desserts", 5.99, false, false));
    menu.addItem(new Items("20","Oreo Sundae", "Desserts", 7.99, false, true));

    return menu;

    
}
    
function filteringData(menu){
    const subBut = document.querySelector('#filter');
    subBut.addEventListener("click", function(sub){
        sub.preventDefault();

        const type = document.querySelector('#mealOptions').value;
        const isVegan = document.querySelector("#checkVegan").checked;
        const isSpicy = document.querySelector("#checkSpicy").checked;
        const price = document.querySelector("#inputPrice").value;

        let meal = menu.filterByType(type);
        let veganBox = menu.filterByPrice(isVegan);
        let spicyBox = menu.filterByVegan(isSpicy);
        let priceValue = menu.filterBySpice(price);

        console.log(meal);
        console.log(veganBox);
        console.log(spicyBox);
        console.log(priceValue);

        const menuElement = document.querySelector('#meal-table');
        menuElement.innerHTML = '';
    
            for (let i = 0; i < menu.item.length; i++) {
                const item = menu.item[i];

                const itemElement = document.createElement('div');
                itemElement.classList.add('food-item');
            
                const itemNumElement = document.createElement('h3');
                itemNumElement.textContent = item.getItemNum();
                itemElement.appendChild(itemNumElement);

                const nameElement = document.createElement('h2');
                nameElement.textContent = item.getName();
                itemElement.appendChild(nameElement);
            
                const typeElement = document.createElement('p');

                
                typeElement.textContent = item.getMealType();
                itemElement.appendChild(typeElement);
            
                const priceElement = document.createElement('strong');
                priceElement.textContent = item.getPrice();
                itemElement.appendChild(priceElement);
            
                
                let ele = item.isVegan();
                menuElement.appendChild(ele);
                
                let spi = item.isSpicy();
                menuElement.appendChild(spi);
                
        
                menuElement.appendChild(itemElement);
            } });




}


main();


//py -m http.server --bind 127.0.0.1