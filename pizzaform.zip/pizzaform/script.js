$(function () {
  $('#pizza_form').on('submit', function(evnt) {
    evnt.preventDefault();
      let yname = document.querySelector('#yourname').value;
      document.querySelector('#your_name').innerHTML = yname;
  });
});
$(function() {
  $('#pizza_form').on('submit', function(evnt) {
    evnt.preventDefault();
      let address = document.querySelector('#youraddress').value;
      document.querySelector('#your_address').innerHTML = address;
  });
});
$(function() {
  $('#pizza_form').on('submit', function(evnt) {
    evnt.preventDefault();
      let numofpie = document.querySelector('#numberofpies').value;
      document.querySelector('#numofpie').innerHTML = numofpie;
  });
});

$(function() {
  $('#pizza_form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#S').checked){
	  document.querySelector('#psize').textContent = "8-inch";
	  }});
});

$(function() {
  $('#pizza_form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#M').checked){
	  document.querySelector('#psize').textContent = "10-inch";
	  }});
});

$(function() {
  $('#pizza_form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#L').checked){
	  document.querySelector('#psize').textContent = "12-inch";
	  }});
});


$(function() {
  $('#pizza_form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#XL').checked){
	  document.querySelector('#psize').textContent = "14-inch";
	  }});
});

$(function() {
  $('#pizza_form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#Pepperoni').checked){
	  document.querySelector('#pepperoni').textContent = "Pepperoni";
	  }});
});


$(function() {
  $('#pizza_form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#Onions').checked){
	  document.querySelector('#onions').textContent = "Onions";
	  }});
});

$(function() {
  $('#pizza_form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#Mushrooms').checked){
	  document.querySelector('#mushrooms').textContent = "Mushrooms";
	  }});
});

$(function() {
  $('#pizza_form').on('submit', function(evnt) {
    evnt.preventDefault();
      if(document.querySelector('#Sausage').checked){
	  document.querySelector('#sausage').textContent = "Sausage";
	  }});
});


