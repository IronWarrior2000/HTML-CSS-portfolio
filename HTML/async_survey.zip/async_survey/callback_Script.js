'use strict';
document.addEventListener('DOMContentLoaded', () => {
    let timeOne = Math.floor(Math.random() * 1000);
    let timeTwo = Math.floor(Math.random() * 1000);
    let greeting;
    let personName;

    setTimeout(() => {
        let greetings = ['Hello', 'Hola', 'Konnichiwa', 'Bonjour', 'Hallo'];
        let randomIndex = Math.floor(Math.random() * greetings.length);
        greeting = greetings[randomIndex];
		solution(greeting, personName);
	}, timeOne);
	
    setTimeout(() => {
        let names = ['Alice', 'Bob', 'Carol', 'Devon'];
        let randomIndex = Math.floor(Math.random() * names.length);
        personName = names[randomIndex];
		solution(greeting, personName);	
	}, timeTwo);
	
	function solution(greeting,personName){
		if(greeting !== undefined && personName !== undefined){
			console.log("Callback Solution: " + greeting + ", "+ personName + "!" );
			document.querySelector("#callback").innerHTML = "Callback Solution: " + greeting + ", "+ personName + "!";
		}
	};
});
	
	
