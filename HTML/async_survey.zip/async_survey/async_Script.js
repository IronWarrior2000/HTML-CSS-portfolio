'use strict';
document.addEventListener('DOMContentLoaded', async () => {
    let timeOne = Math.floor(Math.random() * 1000);
    let timeTwo = Math.floor(Math.random() * 1000);
    let greeting;
    let personName;

	const promiseOne = new Promise((resolve) =>{
		setTimeout(() => {
			let greetings = ['Hello', 'Hola', 'Konnichiwa', 'Bonjour', 'Hallo'];
			let randomIndex = Math.floor(Math.random() * greetings.length);
			greeting = greetings[randomIndex];
			resolve();
		}, timeOne);
	});
	
	const promiseTwo = new Promise((resolve) =>{
		setTimeout(() => {
			let names = ['Alice', 'Bob', 'Carol', 'Devon'];
			let randomIndex = Math.floor(Math.random() * names.length);
			personName = names[randomIndex];
			resolve();
		}, timeTwo);
	});
	
	await Promise.all([promiseOne,promiseTwo]);
	
    console.log("Async Solution:" + greeting + ', ' + personName + '!');
	document.querySelector("#async").innerHTML = "Async Solution: " + greeting + ", "+ personName + "!";

});


