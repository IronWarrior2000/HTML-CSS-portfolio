const fs = require("fs");
const fsPromise = require('fs').promises;


function main(){
    fsPromise
        .readFile('location.csv','utf-8')
        .then((rawData)=> {
            const lines = rawData.split(/[\r\n]+/g);
            const columns = lines.shift().split(',');
            const data = [];
        
            for (const line of lines) {
                const values = line.split(',');
                const obj = {};
            
                for (let i = 0; i < columns.length; i++) {
                  const key = columns[i];
                  const value = values[i];
                  obj[key] = isNaN(value) ? value : parseFloat(value);
                }
                data.push(obj);
            }
            

            console.log(JSON.stringify(data));
        })
        .catch((error)=>{
            console.error("ERROR");
        });

}


main();