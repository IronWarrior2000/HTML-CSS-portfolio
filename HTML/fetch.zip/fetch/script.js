document.addEventListener("DOMContentLoaded",function(){
	let sendbutton = document.getElementById("send");
	sendbutton.addEventListener("click",send);
});

function send(ss){
	ss.preventDefault();
	let jnum = document.querySelector("#jnum").value;
	let message = document.querySelector("#message").value;
	let daform = document.querySelector("#form");
	let sendbutton = document.getElementById("send");
	let resultDiv = document.querySelector('#result');
	let option2 = {
		method:"GET",
		headers: {
			'Accept':'application/json'
        }
	};
	
	sendbutton.addEventListener('click', async () => {
    await fetch('https://messenger.ccp-lessons.com/message', {
        method: 'POST',
        headers: {
			'Accept':'application/json',
            'Content-Type':'application/json'
        },
        body: JSON.stringify({ jnum, message })
    })
	.then((response) => {
		return response.json();
	})
	.then((data) => {
	let retrieve = fetch("https://messenger.ccp-lessons.com/message/JNUM/ID", {
        method: 'GET',
        headers: {
			'Accept':'application/json',
			'Content-Type':'text/html',
        }
    });
	retrieve.then(retrieveData => retrieveData.json())
   retrieve.then(data => {
	   let messageText = data.message;
	  resultDiv.textContent = `Message sent: "${messageText.message}"`;   
   });
   retrieve.catch(error => {
      resultDiv.textContent = 'Error retrieving message from server.';
   });
	retrieve.catch(error => {
    resultDiv.textContent = 'Error sending message to server.';
	});
	
	});
	});
};	
	
	
	
