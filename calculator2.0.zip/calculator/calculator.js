import {addition,
		subtraction,
		multiplication,
		division
		} from "./operations.js");

function calculator(){	
	console.log("test");
	let answer = document.querySelector("#answer").value;
	let num1 = document.querySelector("#number1").value;
	let num2 = document.querySelector("#number2").value;
	let operation = document.querySelector("#operations").value;
	
	if(operation == "+"){
		num3 = addition(num1,num2);
	}
	
	else if(operation == "-"){
		num3 = subtraction(num1,num2);
	}
	
	else if(operation == "x"){
		num3 = multiplication(num1,num2);
	}
	
	else if(operation == "/"){
		num3 = division(num1,num2);		
	}
	
	else
		document.querySelector("#answer").textContent("please pick another number");
	document.querySelector("#answer").textContent = num3;
  };

export {
	calculator,
}