<?php
	$currentPage = $_SERVER['SCRIPT_NAME'];
	$navibar = '';
	$contentarea = '';
	$banner = 'Welcome to Home Only Repair Network Yellow, where we will fix your issues at home.'; 

	$navigations = [
	[
		'Navigate' => 'About',
		
	],
	[
		'Navigate' => 'Contact',
	],
	[
		'Navigate' => 'Service',
	],
];

	$content = [
	
	$textcontent = [				
						[	
							'text' =>
									'<header><h1>'."Welcome to the About page".'</h1></header>'.
									'<p>'."Here you can we are focus on working on your issues that is going on at your home.".'</p>',
						],
						[
							'text' =>
									'<header><h1>'."Welcome to our Contact page".'</h1>'.
										'<p>'. "if you have any questions please contact us at xxx-123-4567. 
												If you are looking for services please take a look at our service page.".'</p></header>',
						],
						[
							'text' => 
									'<header><h1>'."Hello, Welcome to Our Service Page".'</h1></header>'.
										'<p>'."If you request our services please use our contact page to find our number to schedule for an appointment".'</p>',
						],
					],
	$imagecontent = [
						[
							'image' =>	'<img src="images/about.jpeg" alt="about" >',
						],
						[
							'image' =>  '<img src="images/phone-book.png" alt="contact" >',
						],
						[
							'image' => '<img src="images/service.png" alt="service" >',
						],
					],
			 ];

	 if (isset($_GET['page'])) {
        $navindex = (int)$_GET['page'];
        $navidetails = $navigations[$navindex];
        $textcount = $_GET['page'];
        $textofcontent = $textcontent[$textcount];
		$imageofcontent = $imagecontent[$textcount];
		
		
	 };

	foreach ($textcontent as $keys => $textcontent) {
        $contentarea .= '<section>'. $textcontent['text'].'</section>';
    };

    foreach ($navigations as $keys => $navigations) {
        $navibar .= '<nav><a href="' . $currentPage . '?page='
		. $keys . '">'. $navigations['Navigate'].'|' . '</a></nav>';
    };

?>
<!DOCTYPE html>
	<html lang="en">
		<head>
			<meta charset="utf-8">
			<title>Home Repair Services</title>
			<link rel="stylesheet" href="style.css">
		</head>
		<body> 
					<!--Header-->
					
					<!--navi-bar-->
			 <?php if (isset($navidetails) && isset($textofcontent) && isset($imageofcontent)):?>
		 <h1><?php print $navidetails['Navigate'];?></h1>
	 
					<!--content-->
<section><h5><?php print $textofcontent['text'];?></h5></section>
	  <aside><?php print $imageofcontent['image'];?></aside>
			 <?php else:?>
			 
					<!--Home Page-->
<a href="<?php print $currentPage;?>">Home</a>
			 <?php print '| '.$navibar; ?>
 <header><h5><?php print $banner;?></h5></header>
			 <?php print $homeimage ='<img src="images/homerepair.png" alt="home" >'?>
	
			 <?php endif?>
	 
					<!--footer-->
    <p><a href="<?php print $currentPage; ?>">Return Home</a></p>	


	</body>
</html>