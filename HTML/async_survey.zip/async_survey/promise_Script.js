'use strict';
document.addEventListener('DOMContentLoaded', () => {
    let timeOne = Math.floor(Math.random() * 1000);
    let timeTwo = Math.floor(Math.random() * 1000);
    
	let promise = new Promise((resolve, reject) =>{
		let greeting;
		let personName;

		setTimeout(() => {
			let greetings = ['Hello', 'Hola', 'Konnichiwa', 'Bonjour', 'Hallo'];
			let randomIndex = Math.floor(Math.random() * greetings.length);
			greeting = greetings[randomIndex];
			if (personName !== undefined){
				resolve('Resolve Solution: ' + greeting + ','+ personName+'!');
				document.querySelector("#promise").innerHTML = "Promise Solution: " + greeting + ", "+ personName + "!";
			}
		}, timeOne);

		setTimeout(() => {
			let names = ['Alice', 'Bob', 'Carol', 'Devon'];
			let randomIndex = Math.floor(Math.random() * names.length);
			personName = names[randomIndex];
			if (greeting !== undefined){
				resolve('Resolve Solution: ' + greeting + ','+ personName+'!');
				document.querySelector("#promise").innerHTML = "Promise Solution: " + greeting + ", "+ personName + "!";
			}
		}, timeTwo);		
	});
	
	promise.then(result => {
		console.log(result);
		
	});
});
