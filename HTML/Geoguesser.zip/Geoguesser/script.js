let map;
let currentMarker = L.marker([39.9645443084786, -75.16551312659897]);
let score = document.querySelector("#score");

// Independance Hall lat: 39.948995728036174 lon:-75.15003490279162
let firstAreaMarker = L.marker([39.948995728036174, -75.15003490279162]);
let boundariesOne = L.circle ([39.948995728036174, -75.15003490279162],{radius:300});

// City Hall lat: 39.9531700989556, lon: -75.16308633325399
let SecondAreaMarker = L.marker([39.9531700989556, -75.16308633325399]);
let boundariesTwo = L.circle ([39.9531700989556, -75.16308633325399],{radius:300});

// Philadelphia Museum of Art lat: 39.9663757846319, lon: -75.18074488611465
let ThirdAreaMarker = L.marker([39.9663757846319, -75.18074488611465]);
let boundariesThree = L.circle ([39.9663757846319, -75.18074488611465],{radius:300});

function main(){
	document.addEventListener("DOMContentLoaded",() => {
		map = L.map("map").setView([39.9645443084786, -75.16551312659897], 13);

		L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
		attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
		}).addTo(map);
				
		currentMarker.addTo(map);
		navigator.geolocation.watchPosition(getPosition, noGeolocation);
		
		
		if(currentMarker == boundariesOne){
			alert("You are in the first general Area");
			boundariesOne.addTo(map);
			document.querySelector("#clue").textContent("The meeting of the Union from Long Ago")
			
		}
		else if(currentMarker == boundariesOne){
			alert("You are in the first general Area");
			boundariesTwo.addTo(map);
			document.querySelector("#clue").textContent("Center City")

		}
		else if(currentMarker == boundariesOne){
			alert("You are in the first general Area");
			boundariesThree.addTo(map);
			document.querySelector("#clue").textContent("This showed up in the Rocky Movie and also place of Art in a garden")
		}
		else
			console.log(currentMarker);
		submitButton = document.querySelector("#submit");
		submitButton.addEventListener("click", guessForm);	
	});
	
};

function guessForm(gform){
	gform.preventDefault();
	scoreboard = document.createElement("h1");
	score = 0
	scoreUpdated = localStorage.setItem("score",score);
	localStorage.setItem("score", 0);
	
	answer = document.querySelector("#answer").value;
	console.log(answer);
	if(answer == "Independence Hall"){
		score = Number(localStorage.getItem("score"))+1;
		scoreUpdated = Number(localStorage.setItem("score",score))+1;
		document.querySelector("#score").textContent = "Score: "+score;
		return score;
	}
	else if(answer == "City Hall"){
		score = Number(localStorage.getItem("score"))+1;
		scoreUpdated = Number(localStorage.setItem("score",score))+1;
		document.querySelector("#score").textContent = "Score: "+score;
		return score;
	}
	
	else if(answer == "Philadelphia Museum of Art"){
		score = Number(localStorage.getItem("score"))+1;
		scoreUpdated = Number(localStorage.setItem("score",score))+1;
		document.querySelector("#score").textContent = "Score: "+score;
		
		return score;
	}
	else if(score == 3){
		document.querySelector("#score").textContent = "Congrats you beat the game. Thank you for playing";	
	}
		
	else	
		console.log(scoreUpdated);
	
}


function getPosition(position){
	let lat= position.coords.latitude;
	let lon= position.coords.longitude;
	map.panTo([lat,lon]);
	currentMarker.setLatLng([lat, lon]);
	console.log(lat, lon);
	
};

function noGeolocation(log){
	console.log(log);
}

main();