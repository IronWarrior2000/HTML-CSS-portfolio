
let ran= Math.ceil(Math.random() * 100);
let count = 0;

let gnum=Number(prompt("Enter in your guess for a number between 1-100"));

while(gnum !== ran){
count++;	
	if(gnum < ran){
		alert ("Your number " +gnum+" is too low");
	}
	else{
		alert("Your number " +gnum+" is too high");
	}
gnum=Number(prompt("Enter in your guess for a number between 1-100"));	
}

console.log(+ran,"correct " +count);
alert("The answer is " +ran+ ". You got the correct answer. Your guesses is:" +count);
document.write("The answer is " +ran, ". You got the correct answer. Your guesses is:" +count);