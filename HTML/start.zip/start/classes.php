<?php
	//Class Courses Database EXTRACTION
	$class = new PDO('sqlite:data.db');
	
	//Class Fields Security and GET
	$classIdLimits = $_GET['class_id'] ?? '';
	$classIdParam = addcslashes($classIdLimits, '_%'). '%';
	
	$classNameLimits = $_GET['name'] ?? '';
	$classNameParam = addcslashes($classNameLimits, '_%'). '%';
	
	$classDepartmentsLimits = $_GET['department'] ?? '';
	$classDepartmentsParam = addcslashes($classDepartmentsLimits, '_%'). '%';
	
	$classCreditsLimits = $_GET['credits'] ?? '';
	$classCreditsParam = addcslashes($classCreditsLimits, '_%'). '%';
	
	//Class Query
	$queryClass = $class->prepare(
		'SELECT class_id, name, department, credits
		 FROM class
		 WHERE class_id LIKE :class_id AND
			  name LIKE :name AND
			  department LIKE :department AND
			  credits LIKE :credits'
		);
	$queryClass->execute([
		':class_id' => $classIdParam,
		':name' => $classNameParam,
		':department' => $classDepartmentsParam,
		':credits' => $classCreditsParam
	]);
	$trueClass = $queryClass->fetchAll(PDO::FETCH_ASSOC);
	
	//Class Content Type and Print in JSON data.
	header('Content-Type: application/json');
	print json_encode($trueClass);
	
?>


