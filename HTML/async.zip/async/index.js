'use strict';

function updateH1() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            document.querySelector('h1').textContent = 'Hi there!';
            resolve();
        }, 5000);
    });
}

function makeBackgroundPink() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            document.body.style.backgroundColor = 'pink';
            resolve();
        }, 5000);
    });
}

function main() {
    let p1 = updateH1();
    p1
      .then(() => {
        return makeBackgroundPink();
      })
      .then(() => {
        document.querySelector('h1').textContent += '!!!!';
      }); 

    document.body.addEventListener('click', () => {
        document.querySelector('h1').textContent = 'CLICKED!';
    });
}

document.addEventListener('DOMContentLoaded', main);



