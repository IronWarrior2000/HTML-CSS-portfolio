
import {calculator} from "./calculator.js");

function main(){
	document.addEventListener("DOMContentLoaded",function(){
	equal = document.querySelector("#equal");
	equal.addEventListener('click',calculator);


})};


main();


	  



