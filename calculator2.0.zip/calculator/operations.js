	
	
	function addition(num1,num2){
		let operation = document.querySelector("#operations").value;
		if(operation == "+"){
		num3 = parseFloat(num1) + parseFloat(num2);
		return num3;
		
		}
	};
	
	function subtraction(num1,num2){
		let operation = document.querySelector("#operations").value;
		if(operation == "-"){
		num3 = parseFloat(num1) - parseFloat(num2);
		return num3;
		}
	};
	
	function multiplication(num1,num2){
		let operation = document.querySelector("#operations").value;
		if(operation == "x"){
		num3 = parseFloat(num1) * parseFloat(num2);
		return num3;		
		}
	};
	
	function division(num1,num2){
		let operation = document.querySelector("#operations").value;
		if(operation == "/"){
		num3 = parseFloat(num1) / parseFloat(num2);
		return num3;
		}
	};

export{
	addition,
	subtraction,
	multiplication,
	division,
}